export default function RiderDashboard() {
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold">Rider Dashboard</h2>
      <p className="mt-4 text-gray-600">Accept and complete delivery tasks.</p>
    </div>
  );
}