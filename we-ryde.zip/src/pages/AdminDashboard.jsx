export default function AdminDashboard() {
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold">Admin Dashboard</h2>
      <p className="mt-4 text-gray-600">Manage orders, riders, and analytics.</p>
    </div>
  );
}