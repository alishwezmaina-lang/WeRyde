import { Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import CustomerDashboard from "./pages/CustomerDashboard";
import RiderDashboard from "./pages/RiderDashboard";
import AdminDashboard from "./pages/AdminDashboard";

function App() {
  return (
    <div className="font-sans">
      <nav className="bg-blue-600 text-white p-4 flex justify-between">
        <Link to="/">WeRyde</Link>
        <div className="space-x-4">
          <Link to="/customer">Customer</Link>
          <Link to="/rider">Rider</Link>
          <Link to="/admin">Admin</Link>
        </div>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/customer" element={<CustomerDashboard />} />
        <Route path="/rider" element={<RiderDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />
      </Routes>
    </div>
  );
}

export default App;