# WeRyde – FMCG Delivery App (MVP)

**Tagline:** Speed You Can Trust 🚀

WeRyde is a futuristic FMCG delivery platform connecting retailers, distributors, and riders for fast and reliable deliveries.

---

## Features
- Customer dashboard: place & track orders
- Rider dashboard: accept deliveries, live tracking
- Admin panel: manage orders, riders, analytics
- Role-based login (Customer / Rider / Admin)
- Responsive design with TailwindCSS

---

## Tech Stack
- React (Vite)
- TailwindCSS
- React Router
- (Future) Node.js backend + MongoDB/Postgres
- Deployed with Vercel / Netlify

---

## 🚀 Getting Started

Clone repo:
```bash
git clone https://github.com/your-username/we-ryde.git
cd we-ryde
```

Install dependencies:
```bash
npm install
```

Run locally:
```bash
npm run dev
```

Build for production:
```bash
npm run build
```

Deploy on [Vercel](https://vercel.com) or [Netlify](https://www.netlify.com).

---

## Future Roadmap
- Payments (M-Pesa + Stripe)
- Real-time tracking (Google Maps API)
- Mobile app (Expo + React Native)
- AI demand prediction
